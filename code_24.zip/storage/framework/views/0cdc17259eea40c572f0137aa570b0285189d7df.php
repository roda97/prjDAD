<strong>Hello, 
<br><br>
<?php echo e($body); ?>

<br>
<!-- VERIFICAR COM QUE ENDEREÇO VAI FICAR E ALTERAR:
Check it on: http://prjdad.test/#/-->
<br><br>
With regreds, <br>
Group24 DAD
</strong><?php /**PATH C:\laragon\www\prjDAD\resources\views/emails/mail.blade.php ENDPATH**/ ?>