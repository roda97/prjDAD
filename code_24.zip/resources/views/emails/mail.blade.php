<strong>Hello, 
<br><br>
{{ $body }}
<br>
<!-- VERIFICAR COM QUE ENDEREÇO VAI FICAR E ALTERAR:
Check it on: http://prjdad.test/#/-->
<br><br>
With regreds, <br>
Group24 DAD
</strong>